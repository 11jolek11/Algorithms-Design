from task1 import custom_mean, biggest_element, biggest_second_element
import pytest



# class TestTask1:
#     @pytest.mark.parametrize()
#     def test_biggest_element():
#         pass
